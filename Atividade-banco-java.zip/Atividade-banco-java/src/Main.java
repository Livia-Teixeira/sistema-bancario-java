import java.util.ArrayList;
import java.util.Scanner;


// Classe base Conta

abstract class Conta {

    protected String titular;
    protected double saldo;

    public Conta(String titular, double saldoInicial) {
        this.titular = titular;
        this.saldo = saldoInicial;
    }

    // Depositar dinheiro
    public void depositar(double valor) {

        if (valor > 0) {
            saldo = saldo + valor;
            System.out.println("Depósito realizado com sucesso.");
        } else {
            System.out.println("Valor inválido.");
        }

    }

    // Sacar dinheiro
    public void sacar(double valor) {

        if (valor <= saldo) {
            saldo = saldo - valor;
            System.out.println("Saque realizado com sucesso.");

        } else {
            System.out.println("Saldo insuficiente.");
        }

    }

    // Transferir dinheiro
    public void transferir(Conta destino, double valor) {

        if (valor <= saldo) {
            saldo = saldo - valor;
            destino.depositar(valor);

            System.out.println("Transferência realizada com sucesso.");

        } else {
            System.out.println("Saldo insuficiente para transferência.");
        }

    }

    // Método que pode ser sobrescrito
    public void calcularRendimento() {
        System.out.println("Conta comum não possui rendimento.");
    }

    // Mostrar dados da conta
    public void exibirDados() {

        System.out.println("Titular: " + titular);
        System.out.println("Saldo: R$ " + saldo);

    }

}



// Conta Corrente herda de conta

class ContaCorrente extends Conta {

    public ContaCorrente(String titular, double saldoInicial) {
        super(titular, saldoInicial);
    }

    @Override
    public void calcularRendimento() {

        double taxaManutencao = 20.0;
        saldo -= taxaManutencao;

        System.out.println("Taxa de manutenção descontada: R$ " + taxaManutencao);

    }

}


// Conta Poupança. herda de conta

class ContaPoupanca extends Conta {

    private double taxaRendimento = 0.05;

    public ContaPoupanca(String titular, double saldoInicial) {
        super(titular, saldoInicial);
    }

    @Override
    public void calcularRendimento() {

        double rendimento = saldo * taxaRendimento;

        saldo += rendimento;

        System.out.println("Rendimento aplicado: R$ " + rendimento);

    }

}

//Complementando código::

// Classe Banco

class Banco {

    private ArrayList<Conta> contas = new ArrayList<>();
    private final Scanner scanner = new Scanner(System.in);

    //construtor
    //Aqui já tem duas contas para facilitar a demonstração do sistema
    public Banco() {
        //conta 0
        contas.add(new ContaPoupanca("Maria", 1000));
        //conta 1
        contas.add(new ContaCorrente("Rian", 6000));

    }

    // Criar conta. Gerenciamento de contas
    public void criarConta() {

        System.out.println("Digite o nome do titular:");
        scanner.nextLine();
        String nome = scanner.nextLine();

        System.out.println("Digite o saldo inicial:");
        double saldo = scanner.nextDouble();

        System.out.println("Tipo da conta:");
        System.out.println("1 - Conta Corrente");
        System.out.println("2 - Conta Poupança");

        int tipo = scanner.nextInt();

        Conta novaConta;

        if (tipo == 1) {
            novaConta = new ContaCorrente(nome, saldo);
        } else {
            novaConta = new ContaPoupanca(nome, saldo);
        }

        // Adiciona a nova conta para a lista
        contas.add(novaConta);

        System.out.println("Conta criada com sucesso.");

    }

    // Listar contas. Mostrar contas que ja possuem cadastro no banco
    public void listarContas() {

        if (contas.size() == 0) {

            System.out.println("Nenhuma conta cadastrada.");
            return;

        }

        for (int i = 0; i < contas.size(); i++) {

            System.out.println("Conta número: " + i);
            contas.get(i).exibirDados();
            System.out.println("---------------------");

        }

    }

    // Depositar
    public void depositar() {

        System.out.println("Número da conta:");
        int numero = scanner.nextInt();

        System.out.println("Valor do depósito:");
        double valor = scanner.nextDouble();

        contas.get(numero).depositar(valor);

    }

    // Sacar
    public void sacar() {

        System.out.println("Número da conta:");
        int numero = scanner.nextInt();

        System.out.println("Valor do saque:");
        double valor = scanner.nextDouble();

        contas.get(numero).sacar(valor);

    }

    // Transferir
    public void transferir() {

        System.out.println("Conta origem:");
        int origem = scanner.nextInt();

        System.out.println("Conta destino:");
        int destino = scanner.nextInt();

        System.out.println("Valor:");
        double valor = scanner.nextDouble();

        contas.get(origem).transferir(contas.get(destino), valor);

    }

    // Consultar saldo da conta
    public void consultarSaldo() {

        System.out.println("Número da conta:");
        int numero = scanner.nextInt();

        contas.get(numero).exibirDados();

    }

}



// Classe principal

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        Banco banco = new Banco();

        int opcao = -1;

        while (opcao != 0) {

            System.out.println("\n===== BANCO JAVA =====");
            System.out.println("1 - Criar conta");
            System.out.println("2 - Listar contas");
            System.out.println("3 - Depositar");
            System.out.println("4 - Sacar");
            System.out.println("5 - Transferir");
            System.out.println("6 - Consultar saldo");
            System.out.println("0 - Sair");

            System.out.print("Escolha uma opção: ");

            opcao = scanner.nextInt();

            switch (opcao) {

                case 1:
                    banco.criarConta();
                    break;

                case 2:
                    banco.listarContas();
                    break;

                case 3:
                    banco.depositar();
                    break;

                case 4:
                    banco.sacar();
                    break;

                case 5:
                    banco.transferir();
                    break;

                case 6:
                    banco.consultarSaldo();
                    break;

                case 0:
                    System.out.println("Encerrando sistema...");
                    break;

                default:
                    System.out.println("Opção inválida.");

            }

        }

    }

}